# JobPilot — India edition (auto-apply focused)

Upload your resume once. JobPilot searches **Indian job portals**, **company career pages** (Greenhouse / Lever / Ashby), scores each job against your resume, and **applies for you** using the details it extracted from your CV.

**Target mix:** ~90% automatic apply (company sites + portal Easy Apply), ~10% manual (LinkedIn / Hirist / Indeed style sites whose terms forbid bots).

Runs on your own PC. Dashboard: http://127.0.0.1:8000

---

## Quick start

1. Install **Python 3.10+** (on Windows tick "Add to PATH").
2. **Windows:** double-click `run.bat`  
   **Mac / Linux:** `./run.sh`  
   First run installs dependencies (a few minutes). The dashboard opens automatically.
3. Open **My resume** → drop your PDF/DOCX → check name, email, phone, skills, notice period, CTC.
4. Open **Portals** → **Connect** Naukri (and foundit / Shine if you use them) → log in in the browser window → press **I'm logged in**.
5. Open **Jobs** → set roles + cities → **Find jobs**.
6. Press **Select strong matches** → **Auto apply**.

Optional: put `ANTHROPIC_API_KEY` (better scoring + cover notes) and email/phone alerts in `.env`.

---

## What gets auto-applied (~90%)

| Source | How apply works |
|--------|-----------------|
| **Company career pages** (Greenhouse, Lever, Ashby) | Bot opens the form, fills fields from your resume, uploads CV, submits |
| **Naukri, foundit, Shine, Internshala** | Uses *your* logged-in browser; clicks Easy / Quick Apply |
| **Adzuna India** (optional free API key) | Extra listings; apply path depends on the employer site |

Fill **notice period**, **current CTC**, **expected CTC** in My resume so the bot can answer those common questions without stopping.

## What stays manual (~10%)

LinkedIn, Indeed, Instahyre, Cutshort, **Hirist**, Wellfound, TimesJobs, apna — JobPilot only opens a ready-made search. Their terms ban automation; automating them risks account bans. You apply yourself; mark "I applied" in the dashboard.

---

## More jobs than before

- **120+ company boards** (Indian product/startup + global companies that hire in India) via public Greenhouse / Lever / Ashby APIs.
- Portal search reads **more pages per role** and more roles per run.
- Adzuna India if you add a free key (`ADZUNA_APP_ID` / `ADZUNA_APP_KEY`).
- Default min match score **55**, daily apply cap **25** (tune in Settings / `.env`).

Wrong company slugs are skipped silently — you can edit `data/companies.json` freely.

---

## Safety & control

- **Stop** button (top bar / bottom bar) halts search or auto-apply within 1–2 seconds and closes the browser window.
- First week tip: set `AUTO_SUBMIT=false` in `.env` so the bot fills forms and waits for **Approve & submit**. Switch to `true` when you trust it.
- Daily limit + random pauses protect portal accounts. Keep daily applications under ~30.
- Captcha, screening questions, or missing required fields → job goes to **Waiting for you**. The bot never invents answers.
- Portal logins stay only in `data/browser_profiles` on your PC. JobPilot never sees your password.

---

## India-only filters

- Non-India locations are dropped.
- Experience range must roughly match your years of experience (override in Settings).
- Exclude keywords (intern, unpaid, VP, ...) are configurable.

---

## If a portal stops working

Portals redesign pages. JobPilot finds jobs by URL pattern and buttons by visible text. If search returns 0 jobs or "Apply button not found", open the **Flight log** and note the portal — only that block in `app/portals.py` needs a small fix.

---

## Files

```
app/main.py       web server + API
app/pipeline.py   search → score → apply
app/portals.py    Naukri, foundit, Shine, Internshala (+ manual search links)
app/applier.py    Greenhouse / Lever / Ashby form fill + submit
app/sources.py    Adzuna + company career APIs
app/resume.py     resume folder + parsing
app/filters.py    India / city / experience / company filters
data/companies.json   company career boards (expand freely)
static/           dashboard (light + dark)
resume/           put your CV here
```

---

## Environment (`.env`)

```
ANTHROPIC_API_KEY=          # optional, better scoring + cover notes
AUTO_SUBMIT=true            # true ≈ full auto; false = approve each job
MIN_MATCH_SCORE=55
DAILY_APPLY_CAP=25
HEADLESS=true               # company forms
PORTAL_HEADLESS=false       # portals: visible window is safer
ADZUNA_APP_ID=              # optional free key
ADZUNA_APP_KEY=
```

Built for personal use on your machine. Use responsibly and respect each site's terms of service.
