'use strict';
/* JobPilot dashboard. Plain JS, no build step. All text goes through h() / textContent, never innerHTML. */
const $ = s => document.querySelector(s);
const PLANE = 'M2 12 22 3l-5 18-4-7z';

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'value') el.value = v;
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  for (const c of kids.flat()) if (c != null && c !== false) el.append(c.nodeType ? c : document.createTextNode(c));
  return el;
}
const svg = (html, cls) => { const d = document.createElement('div'); d.innerHTML = html; const s = d.firstChild; if (cls) s.setAttribute('class', cls); return s; };

async function api(path, opt = {}) {
  if (opt.json !== undefined) { opt.method = opt.method || 'POST'; opt.headers = { 'Content-Type': 'application/json' }; opt.body = JSON.stringify(opt.json); }
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.detail || r.statusText);
  return j;
}
let toastT;
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 3400); }
const guard = fn => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message || 'Something went wrong'); } };

/* ---------------- state ---------------- */
let S = null, jobs = [], jobsKey = '';
let view = (location.hash || '#jobs').slice(1);
let roles = [], cities = [], portalPick = [], modes = [], tiers = [], types = [];
let filter = 'all';
const sel = new Set();
let searching = false;
const MODES = [['remote', 'Remote'], ['hybrid', 'Hybrid'], ['wfo', 'Work from office']];
const TIERS = [['tier1', 'Top companies'], ['tier2', 'Mid-size'], ['tier3', 'Small / startup']];
const TYPES = [['mnc', 'MNC'], ['product', 'Product'], ['startup', 'Startup'], ['service', 'IT services']];

const STATUS = {
  new: ['Ready to apply', ''], applying: ['Applying now…', ''], ready: ['Form ready', 'Press Approve & submit'],
  needs_human: ['Needs you', ''], applied: ['Applied', ''], failed: ['Failed', ''], skipped: ['Skipped', ''], manual: ['Apply yourself', 'Company site'],
};
const FILTERS = [['all', 'All'], ['new', 'To apply'], ['wait', 'Waiting for you'], ['applied', 'Applied'], ['skipped', 'Skipped']];
const inFilter = (j, f) => f === 'all' || (f === 'new' && ['new', 'applying'].includes(j.status)) ||
  (f === 'wait' && ['ready', 'needs_human', 'failed', 'manual'].includes(j.status)) || (f === 'applied' && j.status === 'applied') || (f === 'skipped' && j.status === 'skipped');

/* ---------------- theme ---------------- */
function setTheme(t) {
  document.documentElement.dataset.theme = t;
  try { localStorage.setItem('jp-theme', t); } catch (e) {}
  $('#theme').setAttribute('aria-checked', t === 'dark');
}
$('#theme').onclick = () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
setTheme(document.documentElement.dataset.theme);

/* ---------------- header + nav ---------------- */
const TABS = [['jobs', 'Jobs'], ['resume', 'My resume'], ['portals', 'Portals'], ['settings', 'Settings']];
function renderNav() {
  const nav = $('#nav'); nav.replaceChildren(...TABS.map(([id, label]) =>
    h('button', { 'aria-current': view === id ? 'page' : null, onclick: () => go(id) }, label)));
  document.querySelectorAll('.view').forEach(v => v.hidden = v.id !== 'v-' + view);
}
function go(v) { view = v; location.hash = v; renderNav(); renderView(); updateDock(); }
window.addEventListener('hashchange', () => { const v = location.hash.slice(1); if (v && v !== view && TABS.some(t => t[0] === v)) go(v); });

function renderLeds() {
  const on = (b, t) => h('span', {}, h('i', { class: 'dot' + (b ? ' on' : '') }), t);
  $('#leds').replaceChildren(on(S.ai_enabled, 'AI'), on(S.email_enabled, 'Email'), on(S.push_enabled, 'Phone'));
}
$('#log-btn').onclick = () => { const p = $('#logpane'); p.hidden = !p.hidden; renderLog(); };
$('#log-close').onclick = () => $('#logpane').hidden = true;
function renderLog() {
  if ($('#logpane').hidden) return;
  const pre = $('#logtext'), atEnd = pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 30;
  pre.textContent = S.log.join('\n') || 'Nothing yet. Start a search and the steps appear here.';
  if (atEnd) pre.scrollTop = pre.scrollHeight;
}

/* ---------------- autopilot (progress + STOP) ---------------- */
function renderAutopilot() {
  const box = $('#auto'), r = S.run;
  if (!r.running) { box.hidden = true; box.replaceChildren(); return; }
  box.hidden = false;
  const pct = r.total ? Math.min(100, Math.round(100 * r.done / r.total)) : 0;
  const title = r.stopping ? 'Stopping…' : r.label || 'Working…';
  const sub = r.stopping ? 'Finishing the current click, then everything halts.' : (r.current || 'Starting…');
  const track = h('div', { class: 'track' + (r.total ? '' : ' idle') },
    h('div', { class: 'fill', style: `width:${pct}%` }),
    (() => { const s = svg(`<svg viewBox="0 0 24 24"><path d="${PLANE}" fill="currentColor"/></svg>`); if (r.total) s.style.left = Math.max(2, pct) + '%'; return s; })());
  box.replaceChildren(h('div', { class: 'ap', role: 'status' },
    h('div', {}, h('b', {}, title + (r.total ? `  ${r.done}/${r.total}` : '')), h('small', {}, sub)),
    h('div', { class: 'acts' },
      r.phase === 'login' && !r.stopping ? h('button', { class: 'btn', onclick: guard(async () => { await api('/api/portals/done', { method: 'POST' }); toast('Checking your login…'); }) }, "I'm logged in") : null,
      h('button', { class: 'stop', disabled: r.stopping, onclick: guard(stopAll) }, h('i'), r.stopping ? 'Stopping' : 'Stop')),
    track));
}
async function stopAll() { await api('/api/stop', { method: 'POST' }); toast('Stopping…'); await refresh(); }

/* ---------------- jobs view ---------------- */
function routeArt() {
  return svg(`<svg class="route" viewBox="0 0 420 300" role="img" aria-label="Flight routes between Indian cities">
    <path class="arc" d="M210 40 C 120 70, 110 150, 150 232"/><path class="arc" d="M210 40 C 300 80, 330 140, 300 200"/>
    <path class="arc" d="M150 232 C 200 280, 260 270, 300 200"/><path class="arc" d="M210 40 C 230 110, 215 170, 150 232"/>
    <path class="arc" d="M70 120 C 100 100, 160 70, 210 40"/><path class="arc" d="M70 120 C 80 170, 110 210, 150 232"/>
    <g><circle class="city" cx="210" cy="40" r="7"/><text x="222" y="36">Delhi</text></g>
    <g><circle class="city" cx="70" cy="120" r="7"/><text x="30" y="108">Mumbai</text></g>
    <g><circle class="city" cx="150" cy="232" r="7"/><text x="100" y="256">Bengaluru</text></g>
    <g><circle class="city" cx="300" cy="200" r="7"/><text x="312" y="204">Chennai</text></g>
    <g><circle class="city" cx="228" cy="170" r="7"/><text x="240" y="168">Hyderabad</text></g>
    <g><circle class="city" cx="330" cy="100" r="7"/><text x="342" y="98">Kolkata</text></g>
    <g transform="translate(262 84) rotate(38)"><path class="plane" d="M-14 0 14 -9l-4 9 4 9z"/></g></svg>`);
}

function chipToggle(list, key, label, onchange) {
  return h('button', { class: 'chip', 'aria-pressed': list.includes(key), onclick: e => {
    const i = list.indexOf(key); i < 0 ? list.push(key) : list.splice(i, 1);
    e.currentTarget.setAttribute('aria-pressed', list.includes(key)); onchange && onchange();
  } }, label);
}

function buildJobsView() {
  const v = $('#v-jobs');
  const input = h('input', { id: 'role-in', placeholder: roles.length ? 'Add a role, press Enter' : 'e.g. DevOps Engineer', 'aria-label': 'Job role', onkeydown: e => {
    if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addRole(input.value); input.value = ''; }
    if (e.key === 'Backspace' && !input.value && roles.length) { roles.pop(); renderRoleChips(); }
  } });
  const chips = h('div', { class: 'chips', id: 'role-chips' });
  const sugg = h('div', { class: 'suggest', id: 'sugg' });
  const hero = h('div', { class: 'hero' },
    h('div', {},
      h('h1', {}, 'Your next job is somewhere in India.'),
      h('p', {}, 'JobPilot reads your resume, searches Indian job portals and company pages, and applies for you. You can stop it any second.'),
      h('div', { class: 'ticket' }, h('label', { for: 'role-in' }, 'Roles you want'), chips, input,
        h('button', { class: 'go', id: 'go', onclick: guard(doSearch) }, 'Find jobs')),
      sugg),
    routeArt());

  const cityRow = h('div', { class: 'grp', id: 'city-row' });
  const filt = h('div', { class: 'filters' },
    h('div', { class: 'grp' }, h('span', { class: 'lab' }, 'Cities'), cityRow),
    h('div', { class: 'grp' }, h('span', { class: 'lab' }, 'Work style'), ...MODES.map(([k, l]) => chipToggle(modes, k, l))),
    h('div', { class: 'grp' }, h('span', { class: 'lab' }, 'Company size'), ...TIERS.map(([k, l]) => chipToggle(tiers, k, l))),
    h('div', { class: 'grp' }, h('span', { class: 'lab' }, 'Company type'), ...TYPES.map(([k, l]) => chipToggle(types, k, l))),
    h('div', { class: 'grp', id: 'portal-row' }));
  v.replaceChildren(hero, h('div', { class: 'card', style: 'margin-top:16px' }, filt),
    h('div', { class: 'bar', id: 'bar' }), h('div', { id: 'list' }));
  renderRoleChips(); renderCities(); renderPortalPick(); renderJobs();
}
function renderRoleChips() {
  $('#role-chips').replaceChildren(...roles.map(r => h('span', { class: 'chip role' }, r,
    h('button', { 'aria-label': 'Remove ' + r, onclick: () => { roles = roles.filter(x => x !== r); renderRoleChips(); } }, '×'))));
  const have = new Set(roles.map(r => r.toLowerCase()));
  const ideas = (S.profile.target_roles || []).filter(r => !have.has(r.toLowerCase()));
  const s = $('#sugg'); s.replaceChildren();
  if (ideas.length) s.append('From your resume: ', ...ideas.slice(0, 6).map(r => h('button', { onclick: () => addRole(r) }, '+ ' + r)));
  else if (!S.resume) s.append(h('span', {}, 'Upload your resume first, then JobPilot suggests roles. '), h('a', { href: '#resume' }, 'Go to My resume'));
}
function addRole(r) { r = r.trim().replace(/,$/, ''); if (r && !roles.some(x => x.toLowerCase() === r.toLowerCase())) roles.push(r); renderRoleChips(); }
function renderCities() {
  $('#city-row').replaceChildren(...S.city_presets.map(c => chipToggle(cities, c, c)),
    h('input', { class: 'chip', style: 'width:150px;cursor:text', placeholder: '+ other city', 'aria-label': 'Add another city', onkeydown: e => {
      if (e.key === 'Enter' && e.target.value.trim()) { cities.push(e.target.value.trim()); renderCities(); } } }));
}
function renderPortalPick() {
  const auto = S.portals.filter(p => p.auto);
  $('#portal-row').replaceChildren(h('span', { class: 'lab' }, 'Search on'),
    ...auto.map(p => h('button', { class: 'chip', 'aria-pressed': portalPick.includes(p.id), onclick: e => {
      const i = portalPick.indexOf(p.id); i < 0 ? portalPick.push(p.id) : portalPick.splice(i, 1);
      e.currentTarget.setAttribute('aria-pressed', portalPick.includes(p.id)); } },
      h('i', { class: 'dot' + (p.connected ? ' on' : '') }), p.name)),
    h('a', { href: '#portals', style: 'font-size:14px' }, 'Connect portals'));
}
async function doSearch() {
  if (!roles.length) { const v = $('#role-in').value; if (v.trim()) addRole(v); }
  if (!roles.length) return toast('Add at least one role first');
  if (S.run.running) return toast('Something is already running. Stop it first.');
  searching = true;
  const r = await api('/api/search', { json: { roles, locations: cities, work_modes: modes, company_tiers: tiers, company_types: types, portals: portalPick } });
  toast(r.started ? 'Searching Indian portals and company pages…' : 'Busy. Try again in a moment.');
  await refresh();
}

function scoreColor(n) { return n >= 75 ? 'var(--green)' : n >= 55 ? 'var(--teal)' : 'var(--saffron)'; }
function pass(j) {
  const [label] = STATUS[j.status] || [j.status];
  const portal = S.portals.find(p => p.id === j.source);
  const canSel = j.apply_mode === 'auto' && ['new', 'failed', 'needs_human'].includes(j.status);
  const tags = [
    j.location && h('span', { class: 'tag' }, j.location),
    j.work_mode && h('span', { class: 'tag ' + j.work_mode }, { remote: 'Remote', hybrid: 'Hybrid', wfo: 'On-site' }[j.work_mode] || j.work_mode),
    j.exp && h('span', { class: 'tag' }, j.exp), j.salary && h('span', { class: 'tag' }, j.salary),
    h('span', { class: 'tag src' }, portal ? portal.name : (j.source || '').split(':')[0]),
  ];
  const acts = [
    h('a', { class: 'btn', href: j.url, target: '_blank', rel: 'noopener' }, 'Open job'),
    j.status === 'ready' && h('button', { class: 'btn pri', onclick: guard(() => act(`/api/jobs/${j.id}/approve`, 'Submitting…')) }, 'Approve & submit'),
    ['failed', 'needs_human'].includes(j.status) && j.apply_mode === 'auto' && h('button', { class: 'btn', onclick: guard(() => act(`/api/jobs/${j.id}/retry`, 'Retrying…')) }, 'Retry'),
    ['new', 'manual', 'needs_human', 'ready', 'failed'].includes(j.status) && h('button', { class: 'btn', onclick: guard(() => setStatus(j.id, 'applied')) }, 'I applied'),
    ['new', 'manual', 'needs_human', 'failed'].includes(j.status) && h('button', { class: 'btn ghost', onclick: guard(() => setStatus(j.id, 'skipped')) }, 'Skip'),
    j.status === 'skipped' && h('button', { class: 'btn', onclick: guard(() => setStatus(j.id, 'new')) }, 'Restore'),
    ['ready', 'applied', 'needs_human', 'failed'].includes(j.status) && j.apply_mode === 'auto' && h('a', { class: 'btn ghost', href: `/shots/job_${j.id}.png`, target: '_blank' }, 'Screenshot'),
  ];
  const note = j.note || (j.reason && j.status === 'new' ? j.reason : '');
  return h('article', { class: `pass s-${j.status}` + (sel.has(j.id) ? ' sel-on' : '') },
    h('div', { class: 'sel' }, canSel ? h('input', { type: 'checkbox', 'aria-label': 'Select ' + j.title, checked: sel.has(j.id), onchange: e => { e.target.checked ? sel.add(j.id) : sel.delete(j.id); renderJobs(); } }) : null),
    h('div', { class: 'main' }, h('h3', {}, j.title), h('p', { class: 'co' }, j.company), h('div', { class: 'tags' }, tags),
      j.matched && j.matched.length ? h('div', { class: 'kw' }, 'Your skills in this job: ', h('b', {}, j.matched.slice(0, 6).join(', '))) : null),
    h('div', { class: 'stub' },
      h('div', { class: 'score' }, h('div', { class: 'ring', style: `--p:${j.score};--c:${scoreColor(j.score)}`, title: 'Match score' }, h('span', {}, j.score)),
        h('div', {}, h('div', { class: 'state' }, label), h('span', { class: 'badge ' + j.apply_mode }, j.apply_mode === 'auto' ? 'JobPilot can apply' : 'You apply'))),
      note ? h('div', { class: 'note' }, note) : null,
      j.applied_by ? h('div', { class: 'note' }, j.applied_by === 'ai' ? 'Applied by JobPilot' : 'Applied by you') : null,
      h('div', { class: 'acts' }, acts)));
}
async function act(path, msg) { const r = await api(path, { method: 'POST' }); toast(r.started ? msg : 'Busy. Try again in a moment.'); await refresh(); }
async function setStatus(id, s) { await api(`/api/jobs/${id}/status`, { json: { status: s } }); await refresh(); }

function renderJobs() {
  if (!$('#list')) return;
  const counts = Object.fromEntries(FILTERS.map(([k]) => [k, jobs.filter(j => inFilter(j, k)).length]));
  $('#bar').replaceChildren(h('h2', {}, jobs.length ? `${jobs.length} jobs found` : 'Jobs'),
    ...FILTERS.map(([k, l]) => h('button', { class: 'pill', 'aria-pressed': filter === k, onclick: () => { filter = k; renderJobs(); } }, l, h('b', {}, counts[k]))),
    jobs.some(j => j.status !== 'applied') ? h('button', { class: 'btn danger', onclick: guard(clearJobs) }, 'Clear unapplied') : null);
  const list = jobs.filter(j => inFilter(j, filter));
  $('#list').replaceChildren(...(list.length ? list.map(pass) : [h('div', { class: 'empty' },
    h('h3', {}, jobs.length ? 'Nothing in this tab' : 'No jobs yet'),
    h('p', {}, jobs.length ? 'Try another tab above.' : 'Add the roles you want, pick your cities, and press Find jobs.'))]));
  updateDock();
}
async function clearJobs() { if (!confirm('Remove all jobs that are not applied yet? Applied jobs stay.')) return; const r = await api('/api/jobs/clear', { method: 'POST' }); toast(`${r.removed} jobs cleared`); sel.clear(); await refresh(); }

/* ---------------- dock (Auto apply) ---------------- */
const eligible = () => jobs.filter(j => j.apply_mode === 'auto' && ['new', 'failed'].includes(j.status));
function updateDock() {
  const d = $('#dock'), run = S && S.run.running;
  if (!S || view !== 'jobs' || (!eligible().length && !sel.size && !run)) { d.hidden = true; return; }
  d.hidden = false;
  const review = !S.prefs.auto_submit;
  const strong = eligible().filter(j => j.score >= S.prefs.min_score);
  d.replaceChildren(...[
    h('div', { class: 'info' }, h('b', {}, sel.size), ' selected', h('div', { class: 'muted', style: 'font-size:12px;opacity:.8' }, `${strong.length} strong matches · ${S.applied_today}/${S.prefs.daily_cap} applied today`)),
    h('button', { class: 'btn', onclick: () => { strong.forEach(j => sel.add(j.id)); renderJobs(); } }, `Select strong matches`),
    sel.size ? h('button', { class: 'btn', onclick: () => { sel.clear(); renderJobs(); } }, 'Clear') : null,
    h('label', { class: 'switch', title: 'ON: JobPilot opens each job and waits for your Approve click. OFF: it applies by itself.' },
      h('input', { type: 'checkbox', checked: review, onchange: guard(async e => { S.prefs.auto_submit = !e.target.checked; await api('/api/prefs', { method: 'PUT', json: { data: S.prefs } }); toast(e.target.checked ? 'I will wait for your approval' : 'I will submit by myself'); updateDock(); }) }), 'Check before submitting'),
    run ? h('button', { class: 'stop', disabled: S.run.stopping, onclick: guard(stopAll) }, h('i'), 'Stop') :
      h('button', { class: 'go', disabled: !sel.size, onclick: guard(startApply) }, 'Auto apply')].filter(Boolean));
}
async function startApply() {
  const r = await api('/api/apply', { json: { ids: [...sel], submit: !!S.prefs.auto_submit } });
  toast(r.started ? 'Auto apply started. Press Stop any time.' : 'Busy. Try again in a moment.'); sel.clear(); await refresh();
}

/* ---------------- resume view ---------------- */
const FIELDS = [['first_name', 'First name'], ['last_name', 'Last name'], ['email', 'Email'], ['phone', 'Mobile (10 digits)'], ['location', 'City'],
  ['current_title', 'Current / last role'], ['current_company', 'Current / last company'], ['years_experience', 'Experience (years)'],
  ['notice_period', 'Notice period (e.g. 30 days)'], ['expected_ctc', 'Expected CTC'], ['current_ctc', 'Current CTC'], ['linkedin', 'LinkedIn URL'], ['github', 'GitHub URL'], ['education', 'Education']];
function buildResumeView() {
  const v = $('#v-resume'), r = S.resume;
  const fileIn = h('input', { type: 'file', accept: '.pdf,.docx,.txt', hidden: true, onchange: guard(() => upload(fileIn.files[0])) });
  const drop = h('div', { class: 'drop', tabindex: 0, role: 'button', onclick: () => fileIn.click(), onkeydown: e => e.key === 'Enter' && fileIn.click(),
    ondragover: e => { e.preventDefault(); drop.classList.add('over'); }, ondragleave: () => drop.classList.remove('over'),
    ondrop: guard(e => { e.preventDefault(); drop.classList.remove('over'); return upload(e.dataTransfer.files[0]); }) },
    h('h3', {}, r ? 'Replace your resume' : 'Drop your resume here'), h('p', { class: 'muted' }, 'PDF, DOCX or TXT. Or click to choose a file.'), fileIn);
  const left = h('div', { class: 'card' },
    h('h2', { style: 'font-size:24px;margin-bottom:12px' }, 'Your resume'),
    r ? h('div', { class: 'file' }, h('div', { class: 'ext' }, r.ext),
      h('div', { style: 'min-width:0' }, h('b', {}, r.name), h('div', { class: 'muted', style: 'font-size:13px' }, `${r.kb} KB · saved ${r.modified}`),
        h('div', { class: 'row', style: 'margin-top:8px' },
          h('a', { class: 'btn', href: '/api/resume/file' }, 'Download'),
          h('button', { class: 'btn', onclick: guard(async () => { await api('/api/resume/open-folder', { method: 'POST' }); toast('Opened the resume folder'); }) }, 'Open folder'),
          h('button', { class: 'btn danger', onclick: guard(removeResume) }, 'Remove')))) : null,
    r ? h('div', { class: 'path', title: 'Every application uses this file' }, r.folder) : null,
    h('div', { style: 'height:14px' }), drop,
    h('ol', { class: 'steps' },
      h('li', {}, 'Your resume is saved in the jobpilot/resume folder on this PC.'),
      h('li', {}, 'JobPilot reads it to fill your details and match jobs.'),
      h('li', {}, 'Every application uses this same file. Replace it any time.'),
      h('li', {}, 'Dropped a file in the folder yourself? ', h('a', { href: '#', onclick: guard(async e => { e.preventDefault(); await api('/api/resume/rescan', { method: 'POST' }); await refresh(true); toast('Resume loaded from the folder'); }) }, 'Load it'))));
  const p = S.profile || {};
  const inputs = {};
  const form = h('div', { class: 'form' }, ...FIELDS.map(([k, l]) => {
    inputs[k] = h('input', { value: p[k] == null ? '' : p[k], id: 'f-' + k });
    return h('div', { class: 'f' + (['education', 'linkedin', 'github'].includes(k) ? ' full' : '') }, h('label', { for: 'f-' + k }, l), inputs[k]);
  }));
  const skills = h('textarea', { rows: 3, id: 'f-skills' }); skills.value = (p.skills || []).join(', ');
  const right = h('div', { class: 'card' },
    h('h2', { style: 'font-size:24px;margin-bottom:4px' }, 'What JobPilot read'),
    h('p', { class: 'muted', style: 'margin:0 0 14px' }, r ? 'Check these. Forms get filled from this, so fix anything wrong.' : 'Upload a resume and the details appear here.'),
    form, h('div', { class: 'f', style: 'margin-top:12px' }, h('label', { for: 'f-skills' }, 'Skills (comma separated)'), skills),
    h('div', { class: 'row', style: 'margin-top:14px' }, h('button', { class: 'btn pri', onclick: guard(async () => {
      const d = { ...p }; for (const [k] of FIELDS) d[k] = inputs[k].value.trim();
      d.years_experience = parseFloat(d.years_experience) || 0;
      d.skills = skills.value.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
      await api('/api/profile', { method: 'PUT', json: { data: d } }); await refresh(true); toast('Details saved'); }) }, 'Save details')));
  v.replaceChildren(h('div', { class: 'two' }, left, right));
}
async function upload(file) {
  if (!file) return;
  const fd = new FormData(); fd.append('file', file);
  toast('Reading your resume…');
  await api('/api/resume', { method: 'POST', body: fd });
  await refresh(); roles = (S.profile.target_roles || []).slice(0, 2); await refresh(true); toast('Resume saved in the resume folder');
}
async function removeResume() { if (!confirm('Remove this resume? It moves to resume/previous.')) return; await api('/api/resume', { method: 'DELETE' }); await refresh(true); }

/* ---------------- portals view ---------------- */
function buildPortalsView() {
  const v = $('#v-portals'), run = S.run;
  const cards = S.portals.filter(p => p.auto).map(p => h('div', { class: 'pcard' + (p.connected ? ' on' : '') },
    h('h3', {}, h('i', { class: 'dot' + (p.connected ? ' on' : '') }), p.name), h('p', { class: 'muted', style: 'margin:0' }, p.blurb),
    h('div', { class: 'row' },
      h('button', { class: 'btn pri', disabled: run.running, onclick: guard(async () => { const r = await api(`/api/portals/${p.id}/connect`, { method: 'POST' }); toast(r.started ? 'A browser window opened. Log in there.' : 'Busy. Try again in a moment.'); await refresh(); }) }, p.connected ? 'Log in again' : 'Connect'),
      p.connected ? h('button', { class: 'btn ghost', onclick: guard(async () => { await api(`/api/portals/${p.id}/disconnect`, { method: 'POST' }); await refresh(true); }) }, 'Disconnect') : null)));
  const role = roles[0] || (S.profile.target_roles || [])[0] || 'software engineer', loc = cities.find(c => c !== 'Remote') || '';
  const linkBox = h('div', { class: 'row' }, 'Loading links…');
  api(`/api/portals/links?role=${encodeURIComponent(role)}&loc=${encodeURIComponent(loc)}`).then(ls => linkBox.replaceChildren(...ls.map(l => h('a', { class: 'btn', href: l.url, target: '_blank', rel: 'noopener' }, l.name)))).catch(() => {});
  v.replaceChildren(
    h('h2', { style: 'font-size:30px;margin-bottom:6px' }, 'Job portals'),
    h('p', { class: 'muted', style: 'margin:0 0 16px;max-width:70ch' }, 'Log in once. JobPilot keeps the login on this PC only and never sees your password. After that it searches and applies through your own account.'),
    h('div', { class: 'pgrid' }, ...cards),
    h('div', { class: 'warn', style: 'margin-top:18px' }, 'Keep the daily limit modest (10 to 20 applications). Portals can restrict accounts that apply too fast, so JobPilot pauses between applications. Leave the browser window alone while it works.'),
    h('h2', { style: 'font-size:24px;margin:28px 0 6px' }, 'Search yourself'),
    h('p', { class: 'muted', style: 'margin:0 0 12px' }, `These sites do not allow bots, so JobPilot only opens a ready search for "${role}"${loc ? ' in ' + loc : ''}. You apply there.`), linkBox);
}

/* ---------------- settings view ---------------- */
function buildSettingsView() {
  const v = $('#v-settings'), p = S.prefs;
  const num = (id, label, val, hint) => h('div', { class: 'f' }, h('label', { for: id }, label), h('input', { id, type: 'number', value: val }), hint ? h('div', { class: 'muted', style: 'font-size:12px;margin-top:3px' }, hint) : null);
  const excl = h('input', { id: 'ex', value: (p.exclude_keywords || []).join(', ') });
  const e1 = num('min', 'Minimum match score', p.min_score, 'Auto apply only picks jobs at or above this.'), e2 = num('cap', 'Applications per day', p.daily_cap, 'Keep it under 20 to protect your accounts.'),
    e3 = num('exp', 'Experience override (years)', p.experience_years == null ? '' : p.experience_years, 'Blank = use your resume.');
  const ok = (b, t) => h('div', { class: 'row' }, h('i', { class: 'dot' + (b ? ' on' : '') }), t);
  v.replaceChildren(h('div', { class: 'two' },
    h('div', { class: 'card' }, h('h2', { style: 'font-size:24px;margin-bottom:14px' }, 'Apply rules'),
      h('div', { class: 'form' }, e1, e2, e3, h('div', { class: 'f full' }, h('label', { for: 'ex' }, 'Skip jobs with these words in the title'), excl)),
      h('div', { class: 'row', style: 'margin-top:14px' }, h('button', { class: 'btn pri', onclick: guard(async () => {
        const d = { ...S.prefs, min_score: +$('#min').value || 60, daily_cap: +$('#cap').value || 15,
          experience_years: $('#exp').value === '' ? null : +$('#exp').value, exclude_keywords: $('#ex').value.split(',').map(s => s.trim()).filter(Boolean) };
        await api('/api/prefs', { method: 'PUT', json: { data: d } }); await refresh(true); toast('Settings saved'); }) }, 'Save settings'))),
    h('div', { class: 'card' }, h('h2', { style: 'font-size:24px;margin-bottom:14px' }, 'Connections'),
      h('div', { style: 'display:grid;gap:10px' },
        ok(S.ai_enabled, S.ai_enabled ? 'AI scoring and cover notes are on' : 'AI is off. Add ANTHROPIC_API_KEY to the .env file for smarter matching.'),
        ok(S.email_enabled, S.email_enabled ? 'Email alerts are on' : 'Email alerts are off. Fill SMTP_USER and SMTP_PASS in .env.'),
        ok(S.push_enabled, S.push_enabled ? 'Phone alerts are on' : 'Phone alerts are off. Set NTFY_TOPIC in .env.')),
      h('div', { class: 'row', style: 'margin-top:14px' }, h('button', { class: 'btn', onclick: guard(async () => { const r = await api('/api/test-notify', { method: 'POST' }); toast(r.sent ? 'Test alert sent' : 'No alert channel is set up yet'); }) }, 'Send test alert')),
      h('p', { class: 'muted', style: 'font-size:13px;margin-top:16px' }, 'The .env file sits in the jobpilot folder. Restart JobPilot after changing it.'))));
}

/* ---------------- plumbing ---------------- */
function renderView() {
  if (view === 'jobs') { if (!$('#role-in')) buildJobsView(); else renderJobs(); }
  else if (view === 'resume') buildResumeView();
  else if (view === 'portals') buildPortalsView();
  else if (view === 'settings') buildSettingsView();
}
let wasRunning = false;
async function refresh(rebuild) {
  S = await api('/api/state');
  const js = await api('/api/jobs');
  const key = JSON.stringify(js);
  const changed = key !== jobsKey; jobsKey = key; jobs = js;
  renderLeds(); renderAutopilot(); renderLog();
  const finished = wasRunning && !S.run.running;
  wasRunning = S.run.running;
  if (finished) {
    if (S.run.summary) toast(S.run.summary);
    else if (searching) toast(`Search finished: ${jobs.length} jobs found`);
    searching = false;
    if (view === 'portals' || view === 'settings') rebuild = true;
  }
  const go_ = $('#go'); if (go_) { go_.disabled = S.run.running; go_.textContent = S.run.phase === 'search' ? 'Searching…' : 'Find jobs'; }
  if (rebuild) { if (view === 'jobs') { $('#v-jobs').replaceChildren(); buildJobsView(); } else renderView(); }
  else if (changed || finished) { if (view === 'jobs') renderJobs(); }
  updateDock();
}
async function init() {
  S = await api('/api/state');
  roles = [...(S.prefs.roles || [])]; if (!roles.length) roles = (S.profile.target_roles || []).slice(0, 2);
  cities = [...(S.prefs.locations || [])]; modes = [...S.prefs.work_modes]; tiers = [...S.prefs.company_tiers]; types = [...S.prefs.company_types];
  portalPick = [...(S.prefs.portals || [])];
  if (!TABS.some(t => t[0] === view)) view = 'jobs';
  if (!S.resume && view === 'jobs') view = 'resume';
  renderNav(); renderView();
  await refresh();
  (function loop() { setTimeout(async () => { try { await refresh(); } catch (e) {} loop(); }, S && S.run.running ? 1500 : 4000); })();
}
init().catch(e => toast('Cannot reach JobPilot: ' + e.message));
